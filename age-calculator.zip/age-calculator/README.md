# Online Age Calculator
Run:   docker compose up --build
Open:  http://localhost:8080
Stop:  Ctrl+C  (or: docker compose down)
Restart policy is "no" - the container never starts automatically.
